using System;
using System.Collections.Generic;

namespace human
{
    class Samurai : Human
    {
        public Samurai(string name) : base(name)
        {
            Health = 200;
        }
        // Build Attack Method
        public override int Attack(Human target)
        {
            base.Attack(target);
            if (target.Health <= 50)
            {
                target.Health = 0;
            }
            return target.Health;

            // target.Health = target.Health - (5 * Strength);
            // Console.WriteLine(target.getHealth);
            // return target.getHealth;
        }
        // Build Meditate Method
        public int Meditate()
        {
            Health = 200;
            System.Console.WriteLine($"{Name} Meditate and have a new hp of {Health}");
            return Health;
        }
    }

}
