using System;
using System.Collections.Generic;

namespace human
{
    class Wizard : Human
    {
        public Wizard(string name) : base(name)
        {
            Health = 50;
            Intelligence = 25; 
        }
        // Build Attack Method
        public override int Attack(Human target)
        {
            target.Health = target.Health - (5 * Intelligence);
            Health = Health + (5 * Intelligence);
            System.Console.WriteLine($"{Name} attak {target.Name} and did {Intelligence * 5} damage. {Name} recieved {Intelligence * 5} off hp,{Name} current hp is {getHealth} and {target.Name} current hp is {target.Health} ");
            return target.Health;
        }
        // Build Heal Method
        public int Heal(Human target)
        {
            target.Health = target.Health + (10 * Intelligence);
            Health = Health + (5 * Intelligence);
            System.Console.WriteLine($"{Name} heal {target.Name} and did {Intelligence * 10} heal. {Name} recieved {Intelligence * 10} off hp,{Name} current hp is {target.Health} ");
            return target.Health;
        }
    }

}
