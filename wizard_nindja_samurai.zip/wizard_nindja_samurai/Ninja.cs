using System;
using System.Collections.Generic;

namespace human
{
    class Ninja : Human
    {
        public Ninja(string name) : base(name)
        {
            Dexterity = 175;
        }
        // Build Attack Method
        public override int Attack(Human target)
        {
            Random rand = new Random();
            if (rand.Next(5) == 0){
                target.Health = target.Health - ((5 * Dexterity) + 10);
                // Console.WriteLine(target.Health);
                return target.Health;
            }
            else{
                target.Health = target.Health - (5 * Dexterity);
                // Console.WriteLine(target.Health);
                return target.Health;
            }
        }
        // Build Steal Method
        public int Steal(Human target)
        {
            target.Health = target.Health - 5;
            Health = Health + 5;
            System.Console.WriteLine($"{Name} steal from {target.Name} and heal, new hp {Health}");
            return Health;
        }
    }

}
